% testLabel
% this script requires draw19 graphic library for drawing matrix
% https://www.mathworks.com/matlabcentral/fileexchange/71745-draw19

for ntst = 1:7
    [Adj,Xadj,titl,nnn,pro] = getData(ntst);
    nnd= length(Xadj) - 1;
    
    fprintf('Profile reduction: %s\n\n',titl);
    fprintf('                      Test no: %d\n',ntst);    
    fprintf('              Number of nodes: %d\n',nnd);
    fprintf('    Nonzeros without diagonal: %d\n',length(Adj))
    
    tic()
    % calculate new labels
    [Nnn,Oldpro,Newpro] = Label(Adj,Xadj);
    toc()
    
    fprintf('Old profile without diagonal: %d\n',Oldpro-nnd)
    fprintf('New profile without diagonal: %d\n',Newpro-nnd);
    fprintf('GPS profile without diagonal: %d\n\n',pro);
    
    fprintf('Original   Reordered      GPS reodered \n')
    fprintf(' Index       Index          index\n')
    for n = 1:nnd
        fprintf('%7d%12d%12d\n',n,Nnn(n),nnn(n))
    end
    if nnd == 1
        continue
    end
    
    % plot old matrix
    drawInit
    drawRect(nnd-1,nnd-1,1,1)
    title(sprintf('%s\nOld matrix profile %d',titl,Oldpro-nnd))
    for i = 1:nnd
        ii = nnd - i + 1;
        scatter(i,ii,50,'k','filled')        
        js = Xadj(i);
        if js == 0
            continue
        end
        je = Xadj(i+1) - 1;
        for j = js:je
            scatter(Adj(j),ii,50,'k')
        end
    end
    grid on
    ax = gca;
    ax.XTick = 1:nnd;
    ax.YTick = 1:nnd;
    drawShow
    
    %Set new numeration
    nAdj  = zeros(size(Adj));
    nXadj = zeros(size(Xadj));
    Onn = zeros(nnd,1);
    Old = Onn;
    for n = 1:nnd
        Old(Nnn(n)) = n;
    end
    k = 0;
    for n = 1:nnd
        i = Old(n);
        js = Xadj(i); 
        if js == 0
            continue
        end
        je = Xadj(i+1) - 1;
        for j = js:je
            k = k + 1;
            nAdj(k) = Nnn(Adj(j));
            if j == js
               nXadj(n) = k;
            end
        end
    end
    nXadj(end) = Xadj(end);

    
    % plot new matrix
    drawInit
    title(sprintf('%s\nNew matrix profile %d',titl,Newpro-nnd))
    drawRect(nnd-1,nnd-1,1,1)
    for i = 1:nnd
        ii = nnd - i + 1;
        scatter(i,ii,50,'k','filled')
        js = nXadj(i);
        if js == 0
            continue
        end
        je = nXadj(i+1) - 1;
        for j = js:je
            scatter(nAdj(j),ii,50,'k')
        end
    end
    grid on
    ax = gca;
    ax.XTick = 1:nnd;
    ax.YTick = 1:nnd;
    drawShow
    
end

function [Adj,Xadj,titl,nnn,pro] = getData(tstno)
%GETDATA -- Test examples from 
%   Algorithm 582: The Gibbs-Poole-Stockmeyer and Gibbs-King Algorithms 
%   for Reordering Sparse Matrices
    nnn = [];
    pro = [];
    switch tstno
        case 1
            titl = 'Symmetric structure';
            tXadj = [ ...
                1    4    8   11   14   17   21   23   25   27   31   33   35   37   39   41 ...
                46   49   50   53   55   57   60   63   64   67   71   72   74   76   77   78 ...
                79   80   81   82   83   84   85   86];
            tAdj = [ ...
                1    2   39    2    3   25   30    3    4   18    4   14   18    5    6    8 ...
                6    7   11   31    7    8    8    9    9   39   10   11   13   32   11   12 ...
                12   13   13   14   14   15   15   16   16   17   19   21   24   17   18   27 ...
                18   19   20   33   20   34   21   22   22   23   35   23   24   36   24   25 ...
                26   37   26   27   28   29   27   28   29   29   38   30   31   32   33   34 ...
                35   36   37   38   39];
            pro = 100;
            nnn = zeros(length(tXadj)-1,1);
        case 2
            titl = 'Symetric tridiagonal out of order';
            tXadj = [    1    3    5    7    9   10]';
            tAdj = [ 1    3    2    4    3    5    4    5    5]';
            pro = 4;
            nnn = [1 5 2 4 3];
        case 3
            titl = 'Dense matrix';
            tXadj = [ 1    7   12   16   19   21 22];
            tAdj =  [1    2    3    4    5    6 ...
                2    3    4    5    6    3 ...
                4    5    6    4    5    6 ...
                5    6    6];
            pro = 15;
            nnn = [1 6 2 3 4 5];
        case 4
            titl = 'Diagonal';
            tXadj = [ 1    2    3    4    5    6  7];
            tAdj =  [1    2    3    4    5    6];
            nnn = 1:6;
            pro = 0;
        case 5
            titl = 'Arrow matrix';
            tXadj = [1   11   12   13   14   15   16   17   18   19   20];
            tAdj = [1    2    3    4    5    6    7    8    9   10    2    3    4    5    6    7 ...
                8    9   10];
            pro = 15;
            nnn = [6 1 7 2 8 3 9 4 10 5];
        case 6
            titl = 'One by one matrix';
            tXadj = [1 2];
            tAdj  = 1;
            nnn = 1;
            pro = 0;
        case 7
            titl = 'Tridiagonal matrix plus corner elements';
            tXadj = [1    4    6    8   10   12   13];
            tAdj  = [1    2    6    2    3    3    4    4    5    5    6    6];
            nnn  = [1 2 4 6 5 3 ];
            pro  = 9;
    end
    
    % Convert alg582 data structure to Label structure:
    %   tXadj =  Index array to tAdj
    %   tAdj  =  Adjacency list for all nodes in graph. Only upper triangle
    %   is stored, the diagonal node is the first in the list. Thus nodes
    %   adjecent to node i are found in tAdj(j), where tAdj(tXadj(i)) = i
    %   and j=tXadj(i),tXadj(i)+1,...,tXadj(i+1)-1
    
    % max node degree
    nnd= length(tXadj) - 1;
    mxdg = 0;
    for i = 1:nnd
        js = tXadj(i);
        je = tXadj(i+1) - 1;
        dg = length(tAdj(js+1:je));
        if dg > mxdg
            mxdg = dg;
        end
    end
    % craete connectivity matrix
    C = zeros(2*mxdg,nnd);
    ix = zeros(nnd,1); % # of nodes adj. to node i
    for i = 1:nnd
        js = tXadj(i);
        je = tXadj(i+1) - 1; 
        for j = js + 1:je
            jj = tAdj(j);
            ix(i) = ix(i) + 1;
            C(ix(i),i) = jj;
            ix(jj) = ix(jj) + 1;
            C(ix(jj),jj) = i;
        end
    end
    % form Label adj. list data structure
    Adj = zeros(size(C(C>0),1),1);
    Xadj = zeros(nnd+1,1);
    k = 0;
    for i = 1:nnd
        for j = 1:2*mxdg
            if  C(j,i) == 0
                break
            end
            k = k + 1;
            Adj(k) = C(j,i);
            if j == 1
                Xadj(i) = k;
            end
        end
    end
    Xadj(end) = length(Adj)+1;
end



