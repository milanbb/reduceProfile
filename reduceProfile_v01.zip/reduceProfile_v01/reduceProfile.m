function [Nnn,Oldpro,Newpro,Adj,Xadj] = reduceProfile(IX)
%REDUCEPROFILE Reduce profile of matrix stored in skyline form
%
%Input:
%   IX     -- element nodes IX(nen,numel)
%
%Output:
%   Nnn    -- List of new node numbers 
%   Oldpro -- Profile using origi?al node numbering 
%   Newpro -- Profile for new node numbering 
%   Adj    -- Adjacency list for all nodes in graph 
%   Xadj   -- Index vector for ADJ
%
%
    narginchk(1,1)
    nargoutchk(1,5)
    validateattributes(IX,{'numeric'},{'real','2d'});  
    
    [nen,~] = size(IX); % number of nodes per element
    
    % Form ajecency list for elements (assume tat all elements has nen
    % nodes)
    Npn = IX(:); 
    Xnpn = 1:nen:length(Npn);  
    Xnpn(end+1) = length(Npn) + 1;
    
    % Form adjacency list for a graph corespond to FE mesh
    [Adj,Xadj] = Graph(nen,Npn,Xnpn);
    
    % Label a graph for small profile and rms wavefront
    [Nnn,Oldpro,Newpro] = Label(Adj, Xadj);
end





