% REDUCE_V01
%
% Files
%   Graph             - Form adjacency list for a graph corresponding to a finite element
%   Label             - Label a graph for small profile and rms wavefront
%   reduceProfile     - Reduce profile of matrix stored in skyline form
%   testLabel         - test
%   testLabel0        - testLabel0
%   testReduceProfile - testReduceProfile
