% testLabel0
%
%           6 --- 5 --- 4
%           | \   |  /  |
%           |   \ | /   |
%           1 --- 2 --- 3 
% Data
Adj = [ 2 6 ...
        1 3 6 5 4 ...
        2 4 ...
        2 3 5 ...
        2 4 6 ... 
        1 2 5];
Xadj = [1 3 8 10 13 16 19];

% Number of nodes
nnd = length(Xadj) - 1;

fprintf('Profile reduction\n\n');
fprintf('             Number of nodes: %d\n',nnd);
fprintf('   Nonzeros without diagonal: %d\n',length(Adj))

tic()
% calculate new labels
[Nnn,Oldpro,Newpro] = Label(Adj,Xadj);
toc()

fprintf('                  Old profil: %d\n',Oldpro)
fprintf('                  New profil: %d\n\n',Newpro);

fprintf('Original   Reordered\n')
fprintf(' Index       Index\n')
for n = 1:nnd
    fprintf('%7d%12d\n',n,Nnn(n))
end

%{
% this part requires draw19 graphic library for drawing matrix
% https://www.mathworks.com/matlabcentral/fileexchange/71745-draw19
 % plot old matrix
    drawInit
    drawRect(nnd-1,nnd-1,1,1)
    title(sprintf('%s\nOld matrix profile %d',titl,Oldpro-nnd))
    for i = 1:nnd
        ii = nnd - i + 1;
        scatter(i,ii,50,'k','filled')        
        js = Xadj(i);
        if js == 0
            continue
        end
        je = Xadj(i+1) - 1;
        for j = js:je
            scatter(Adj(j),ii,50,'k')
        end
    end
    grid on
    ax = gca;
    ax.XTick = 1:nnd;
    ax.YTick = 1:nnd;
    drawShow
    
    %Set new numeration
    nAdj  = zeros(size(Adj));
    nXadj = zeros(size(Xadj));
    Onn = zeros(nnd,1);
    Old = Onn;
    for n = 1:nnd
        Old(Nnn(n)) = n;
    end
    k = 0;
    for n = 1:nnd
        i = Old(n);
        js = Xadj(i); 
        if js == 0
            continue
        end
        je = Xadj(i+1) - 1;
        for j = js:je
            k = k + 1;
            nAdj(k) = Nnn(Adj(j));
            if j == js
               nXadj(n) = k;
            end
        end
    end
    nXadj(end) = Xadj(end);

    
    % plot new matrix
    drawInit
    title(sprintf('%s\nNew matrix profile %d',titl,Newpro-nnd))
    drawRect(nnd-1,nnd-1,1,1)
    for i = 1:nnd
        ii = nnd - i + 1;
        scatter(i,ii,50,'k','filled')
        js = nXadj(i);
        if js == 0
            continue
        end
        je = nXadj(i+1) - 1;
        for j = js:je
            scatter(nAdj(j),ii,50,'k')
        end
    end
    grid on
    ax = gca;
    ax.XTick = 1:nnd;
    ax.YTick = 1:nnd;
    drawShow

%}

