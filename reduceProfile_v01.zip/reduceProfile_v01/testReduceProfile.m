% testReduceProfile
%
%           6 --- 5 --- 4
%           | \   |  /  |
%           |   \ | /   |
%           1 --- 2 --- 3 
% Data 4 elements with 3 nodes
IX = [ 1 2 6; 2 5 6; 2 3 4; 2 4 5]';

fprintf('Profile reduction\n\n');
fprintf('          Number of elements: %d\n',size(IX,2));
fprintf(' Number of nodes per element: %d\n',size(IX,1));

tic()
[Nnn,Oldpro,Newpro,Adj,Xadj] = reduceProfile(IX);
toc()

% Number of nodes
nnd = length(Nnn);

fprintf('             Number of nodes: %d\n',nnd);
fprintf('   Nonzeros without diagonal: %d\n',length(Adj))
fprintf('                 Old profile: %d\n',Oldpro)
fprintf('                 New profile: %d\n\n',Newpro);

fprintf('Original   Reordered\n')
fprintf(' Index       Index\n')
for n = 1:nnd
    fprintf('%7d%12d\n',n,Nnn(n))
end