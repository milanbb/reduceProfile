function [Nnn,Oldpro,Newpro] = Label(Adj, Xadj)
%LABEL  Label a graph for small profile and rms wavefront
% 
% This is MATLAB translation of FORTRAN code by Scott Sloan ([1]).
% The subroutine ISORTI (using insertion sort) is replaced by straight 
% selection sort ([2], Program 2.3)
%
%Input:
%   Adj    -- Adjacency list for all nodes in graph 
%   Xadj   -- Index vector for ADJ
%
%Output:
%   Nnn    -- List of new node numbers 
%   Oldpro -- Profile using origi?al node numbering 
%   Newpro -- Profile for new node numbering 
%
%References:
%   [1] S.W.Sloan - A FORTRAN PROGRAM FOR PROFILE AND WAVEFRONT REDUCTION, 
%   International Journal for Numerical Methods in Engineering, 
%   Vol. 28,2651-2679 (1989)
%   [2] N.Wirth - ALGORITHMS + DATA STRUCTURES = PROGRAMS,Prentice-Hall,
%   Inc., 1976

    narginchk(2,2);
    nargoutchk(1,3);
    
    validateattributes(Adj,{'numeric'}, {'integer','vector'});
    validateattributes(Xadj,{'numeric'}, {'integer','vector'});
            
    n = length(Xadj) - 1; %Total number of nodes in graph
    if n == 1
        % 1x1 matrix
        Nnn = 1;
        Oldpro = 1;
        Newpro = 1;
        return
    end
    if isempty(Adj) 
        % diagonal matrix
        nnd = length(Xadj) - 1;
        Nnn = 1:nnd;
        Oldpro = nnd;
        Newpro = nnd;
        return
    end
    if min(Xadj(1:n)) == 0
        error('Index array contains errors.')
    end
    
    % Set all new node numbers = 0 
    % This is used to denote all visible nodes     
    Nnn = zeros(n,1);
    Iw1 = zeros(n,1);
    Iw2 = zeros(n+1,1);
    
    % Loop while some nodes remain unnumbered 
    lstnum = 0;
    while lstnum < n
        
        % Find end points of p-diameter for nodes in this component
        % Compute distances of nodes from end node 
        [Nnn,Iw1,Iw2,Nc,Snode] = diamtr(Adj,Xadj,Nnn,Iw1,Iw2);
        
        % Number nodes in this component
        [lstnum,Nnn,Iw1] = number(Nc,Snode,lstnum,Adj,Xadj,Nnn,Iw1);
        
    end
    
    % Compute profiJes for old and new node numbers 
    [Oldpro,Newpro] = profil(Nnn, Adj, Xadj);
    
    % Use original numbering if it gives a smaller profile
    if Oldpro < Newpro
       Nnn = 1:n;
       Newpro = Oldpro;
    end
    
end

function [Mask,Ls,Xls,Nc,Snode] = diamtr(Adj,Xadj,Mask,Ls,Xls)
%DIAMTR Find nodes which define a psuedo-diameter of a graph and store
%   distances from end node
%
%Input:
%   Adj    -- Adjacency list for all nodes in the graph
%   Xadj   -- Index vector for Adj 
%   Mask   -- Masking vector for graph 
%                Visible nodes have Mask = 0,  node invisible otherwise
%
%Output:
%   Mask   -- List of distnce of nodes from the end
%   Ls     -- List of nodes in the component
%   Snode  -- Starting node for numbering
%   Nc     -- The number of nodes in this component of graph
%
%Note:
%   'Snode' and 'Enode' define a pseudo-diameter

    n = length(Xadj) - 1; %Total number of nodes in graph       
       
    % allocate work arrays
    hlevel = zeros(n,1);
    
    % Choose first guess for starting node by min degree
    % Ignore nodes that are invisible (Mask ~= 0)
    Snode = 0;
    mindeg = n;
    for i = 1:n
        if Mask(i) == 0
            degree = Xadj(i+1) - Xadj(i);
            if degree < mindeg
                Snode = i;
                mindeg = degree;
            end
        end
    end
    if Snode == 0
        error('Start node not found')
    end
    
    %Generate level structure for node with min degree
    [Mask,Ls,Xls,sdepth,~] = rootls(Snode,n + 1,Adj,Xadj,Mask,Ls,Xls);
    
    %Store number of nodes in this component
    Nc = Xls(sdepth+1) - 1;
    
    %Iterate to find start and end nodes
    found = true;
    while found
        found = false;
        % Store list of nodes that are at max distance from starting node
        % Store their degrees in Xls
        hsize = 0;
        istrt = Xls(sdepth);
        istop = Xls(sdepth+1) - 1;
        for i = istrt:istop
            node = Ls(i);
            hsize = hsize + 1;
            hlevel(hsize) = node;
            Xls(node) = Xadj(node+1) - Xadj(node);
        end
        
        %Sort list of nodes in ascending sequence of their degree
        if hsize > 1
            hlevel(1:hsize) = isorti(hlevel(1:hsize),Xls(1:n));
        end
        
        % Remove nodes with duplicate degrees
        istop = hsize;
        hsize = 1;
        degree = Xls(hlevel(1));
        for i = 2:istop
            node = hlevel(i);
            if Xls(node) ~= degree
                degree = Xls(node);
                hsize = hsize + 1;
                hlevel(hsize) = node;
            end
        end
        
        %Loop over nodes in shrunken level
        ewidth = Nc + 1;
        for i = 1:hsize
            node = hlevel(i);
            
            % Form rooted level structures for each node in shrunken level
            [Mask,Ls,Xls,depth,width] = rootls(node,ewidth,Adj,Xadj,Mask,Ls,Xls);
            
            if width < ewidth
                
                %Level structure was not aborted during assembly
                if depth > sdepth
                    
                    %Level structure of greater depth found
                    %Store new starting node, new max depth, and begin
                    %a new iteration
                    Snode = node;
                    sdepth = depth;
                    found = true;
                    break
                end
                
                % Level structure width for this end node is smallest so far
                % store end node and new min width
                enode = node;
                ewidth = width;
            end
        end
    end
    
    %Generate level structure rooted at end node if necessary 
    if node ~= enode
        [Mask,Ls,Xls,depth,~] = rootls(Snode,Nc + 1,Adj,Xadj,Mask,Ls,Xls);
    end
    
    % Store distances of each node from end node 
    for i = 1:depth
        jstrt = Xls(i);
        jstop = Xls(i+1) - 1;
        for j = jstrt:jstop
            Mask(Ls(j)) = i - 1;
        end
    end

end

function [Mask,Ls,Xls,Depth,Width] = rootls(Root,Maxwid,Adj,Xadj,Mask,Ls,Xls)
%ROOTLS Generate rooted level structure  
%
%Input:
%   Root    -- Root node for level structure
%   Maxwid  -- Max permissible width of rooted level structure
%              Assembly ensured by setting Maxwid = n + 1
%   Adj     -- Adjacency list for all nodes in graph
%   Xadj    -- Index vector for Adj
%   Mask    -- Masking vector for graph. Visible nodes has Mask == 0
%
%Output:
%   Ls      -- List containing a rooted level structure
%   Xls     -- Index vector for Ls
%   Depth   -- Number of levels in rooted level structure
%   Width   -- Width of rooted level structure
%
%Note:
%   If Width >= Maxwid then assembly has been aborted

   % n = length(Xadj) - 1; %Total number of nodes in graph
   % Ls = zeros(n,1);
   % Xls = zeros(n+1,1);
    
    % Initialisation
    Mask(Root) = 1;
    Ls(1) = Root;
    nc = 1;
    Width = 1;
    Depth = 0;
    lstop = 0;
    lwdth = 1;
    while lwdth > 0
        
        %'lwdth' is the width of the current level
        %'lstrt' points to start of current level
        %'lstop' points to end of current level
        %'nc'    counts the nodes in component
        lstrt = lstop + 1;
        lstop = nc;
        Depth = Depth + 1;
        Xls(Depth) = lstrt;
        
        % Generate next level by finding all visible neighbours
        % of nodes in current level
        for i = lstrt:lstop
            node = Ls(i);
            jstrt = Xadj(node);
            jstop = Xadj(node+1) - 1;
            for j = jstrt:jstop
                nbr = Adj(j);
                if Mask(nbr) == 0
                    nc = nc + 1;
                    Ls(nc) = nbr;
                    Mask(nbr) = 1;
                end
            end
        end
        
        % Compute width of level just assembled and the width of the
        % level structure so far
        lwdth = nc - lstop;
        Width = max(lwdth,Width);
        
        % Abort assembly if level structure is too wide
        if Width >= Maxwid
            break
        end       
    end
    Xls(Depth+1) = lstop + 1;
    
    % Reset MASK=0 for nodes in the level structure
    for i = 1:nc
        Mask(Ls(i)) = 0;
    end
    
end

function List = isorti(List,Key)
%ISORTI Order a list of integers in ascending sequence of their keys
%using straight selection sort  
%
%Input:
%   List - A list of integers
%   Key  - A list of integer keys
%
%Output:
%   List -  A list of integers sorted in ascending sequence of key
%
    narginchk(2,2)
    nargoutchk(1,1)
    validateattributes(List, {'numeric'}, {'integer','vector'});
    validateattributes(Key,  {'numeric'}, {'integer','vector'});    

    nl = length(List);
    nk = length(Key);
    if nk < nl
        error('nl must be ge nl.')
    end
    
    for i = 1:nl - 1
        k = i;        
        t = List(i);
        for j = i+1:nl
            if Key(t) >= Key(List(j))
                k = j;
                t = List(j);
            end
        end
        List(k) = List(i);
        List(i) = t;
    end
end

function [Lstnum,S,Q] = number(Nc,Snode,Lstnum,Adj,Xadj,S,Q)
%NUMBER Number nodes for small profile and rms wavefront 
%
%Input:
%   Nc      - Number of nodes in component of graph 
%   Snode   - Node at which numbering starts 
%   Lstnum  - Count of nodes which have already been numbered 
%   Adj     - Adjacency list for all nodes in graph 
%   Xadj    - Index vector for ADJ 
%   S       - List giving the distance of each node
%   Q       - List of nodes which are in this component
%
%Output:
%   Lstnum  - Count of numbered nodes 
%   S       - List of new node numbers
%
%Notes:
%   S also serves as a list giving the status of the nodes
%   during the numbering process:
%   S(i) gt 0 indicates node I is postactive
%   S(i) = 0 indicates node I is active
%   S(i) = -1 indicates node I is preactive
%   S(i) = -2 indicates node I is inactive
%   P is used to hold the priorities for each node

    % set weights
    w1 = 1;
    w2 = 2;
    
    n = length(Xadj) - 1;  % Number of nodes in graph 
    P = zeros(n,1);
    
    % Initialise priorities and status for each node
    for i = 1:Nc
        node    = Q(i);
        P(node) = w1*S(node) - w2*(Xadj(node+1) - Xadj(node) + 1);
        S(node) = -2;
    end
    
    % Insert starting node in queue and assign it a preactive status
    nn = 1;
    Q(nn) = Snode;
    S(Snode) = -1;
    
    % Loop while queue is not empty 
    while nn > 0
        
        % Scan queue for node with max priority
        adress = 1;
        maxprt = P(Q(1));
        for i = 2:nn
            prty = P(Q(i));
            if prty > maxprt
                adress = i;
                maxprt = prty;
            end
        end
        
        % 'next' is the node to be numbered next
        next = Q(adress);
        
        % Delete node 'next' from queue 
        Q(adress) = Q(nn);
        nn = nn - 1;
        istrt = Xadj(next);
        istop = Xadj(next+1) - 1;
        if S(next) == -1
            
            % Node NEXT is preactive, examine its neighbours 
            for i = istrt:istop
                
                %Decrease current degree of neighbour by -1
                nbr = Adj(i);
                P(nbr) = P(nbr) + w2;
                
                % Add neighbour to goeue if it is inactive assign it 
                % a preactive status 
                if S(nbr) == -2
                    nn = nn + 1;
                    Q(nn) = nbr;
                    S(nbr) = -1;
                end
            end
        end
        
        % Store new node number for node 'next'
        % Status for node 'next' is now postactive
        Lstnum = Lstnum + 1;
        S(next) = Lstnum;
        
        % Search for preactive neighbours of node 'next'
        for i = istrt:istop
            nbr = Adj(i);
            if S(nbr) == -1
                
                % Decrease current degree of preactive neighbour by -1
                % assign neighbour an active status
                P(nbr) = P(nbr) + w2;
                S(nbr) = 0;
                
                % Loop over nodes adjacent to preactive neighbour 
                jstrt = Xadj(nbr);
                jstop = Xadj(nbr+1) - 1;
                for j = jstrt:jstop
                    nabor = Adj(j);
                    
                    % Decrease current degree of adjacent node by -1 
                    P(nabor) = P(nabor) + w2;
                    if S(nabor) == -2
                        
                        %Insert inactive node in queue with a preactive status 
                        nn = nn + 1;
                        Q(nn) = nabor;
                        S(nabor) = -1;
                    end
                end                        
            end
        end
    end
    
end

function [Oldpro,Newpro] = profil(Nnn, Adj, Xadj)
%PROFIL Compute the profiles using both original and new node numbers
%   
%Input:
%   Nnn    -- List of new node numbers for graph
%   Adj    -- Adjacency list for all nodes in graph
%   Xadj   -- Index vector for 'Adj'
%
%Output:
%   Oldpro -- Profile with original node numbering
%   Newpro -- Profile with m w node numbering
%
%Note:
%   Profiles include diagonal terms
%

    n = length(Xadj) - 1; %Total number of nodes in graph
    
    % Set profiles and loop over each node in graph
    Oldpro = 0;
    Newpro = 0;
    for i = 1:n
        jstrt = Xadj(i);
        jstop = Xadj(i+1) - 1;
        oldmin = Adj(jstrt);
        newmin = Nnn(Adj(jstrt));
        
        % Find lowest numbered neighbour of node I 
        % (using both old and new node numbers)
        for j = jstrt + 1:jstop
            oldmin = min(oldmin,Adj(j));
            newmin = min(newmin,Nnn(Adj(j)));
        end
        
        % Update profiles
        Oldpro = Oldpro + dim(i,oldmin);
        Newpro = Newpro + dim(Nnn(i),newmin);
    end
    
    % Add diagonal terms to profiles
    Oldpro = Oldpro + n;
    Newpro = Newpro + n;

end

function res = dim(x,y)
%DIM(X,Y) returns the difference X-Y if the result is positive; 
%   otherwise returns zero.
    res = max(0,x - y);
end
