function [Adj,Xadj] = Graph(nen,Npn,Xnpn)
%GRAPH Form adjacency list for a graph corresponding to a finite element
% mesh
%
% This is MATLAB translation of FORTRAN code GRAPH by Scott Sloan ([1]).
%
%Input:
%   nen  - number of nodes per element
%   Npn  - List of node numbers for each element 
%   Xnpn - Index vector for Npn
%
%Output:
%   Adj  - Adjacency list for all nodes in graph 
%   Xadj - Index vector for Adj
%
%Notes:
%   Nodes adjecent to node i are fond in Adj(i), where
%       j=Xadj(i),Xadj(i)+1,...,Xadj(i+1)-1
%   Degree of node i is given by Xadj(i+1) - Xadj(i);
%   Total number of nodes in graph is n = length(Xadj) - 1
%   Number of edges E in the graph is 2*E = Xadj(n+1)-1)
%   Length of Xadj array is n + 1;
%   Length of Adj is 2*E;
%   Xadj(n+1) = length(Adj) + 1
%
%References:
%   [1] S.W.Sloan - A FORTRAN PROGRAM FOR PROFILE AND WAVEFRONT REDUCTION, 
%   International Journal for Numerical Methods in Engineering, 
%   Vol. 28,2651-2679 (1989)

        
    ne = length(Xnpn) - 1; % number of elements
    n  = max(Npn);         % Number of nodes in graph
    nadj = ne*nen*(nen - 1);
       
    % Initialise the adjacency list and its index vector 
    Xadj = zeros(n+1,1);
    Adj  = zeros(nadj,1);
    
    %Estimate the degree of each node (always an overestimate) 
    for i=1:ne
        jstrt = Xnpn(i);
        jstop = Xnpn(i+1)-1;
        nen1  = jstop - jstrt;
        for j = jstrt:jstop
            nodej = Npn(j);
            Xadj(nodej) = Xadj(nodej) + nen1;
        end
    end

    %Reconstruct xadj to point to start of each set of neighbours 
    l = 1;
    for i = 1:n
        l = l + Xadj(i);
        Xadj(i) = l - Xadj(i);
    end
    Xadj(n+1) = l;

    % form adjacency list (which may contain zeros) 
    for i=1:ne
        jstrt = Xnpn(i);
        jstop = Xnpn(i+1) - 1;
        for  j = jstrt:jstop-1
            nodej = Npn(j);
            lstrt = Xadj(nodej);
            lstop = Xadj(nodej+1) - 1;
            for k = j + 1:jstop
                nodek = Npn(k);
                found = false;
                for  l = lstrt:lstop
                    if Adj(l) == nodek
                        found = true;
                        break
                    end
                    if Adj(l) == 0
                        found = true;
                        break
                    end
                end
                if ~found
                    error('***Error in graph: cannot assemble node adjacency list.')
                end
                if Adj(l) == nodek                    
                    continue
                end
                Adj(l) = nodek;
                mstrt = Xadj(nodek);
                mstop = Xadj(nodek+1)-1;
                found = false;
                for m = mstrt:mstop
                    if Adj(m) == 0
                        found = true;
                        break
                    end
                end
                if ~found
                    error('***Error in graph: cannot assemble node adjacency list.')
                end
                Adj(m) = nodej;
            end
        end
    end

    %Strip any zeros from adjacency list     
    k = 0;
    jstrt = 1;
    for i=1:n
        jstop = Xadj(i+1) - 1;
        for j = jstrt:jstop
            if Adj(j) == 0
                break
            end
            k = k + 1;
            Adj(k) = Adj(j);
        end
        Xadj(i+1) = k + 1;
        jstrt = jstop + 1;
    end
    Adj = Adj(1:k);  
end



